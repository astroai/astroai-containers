"""Thin wrappers around canfar session CLI (out-of-session convenience)."""

from __future__ import annotations

import shutil
from typing import Annotated

import typer

from astroai_lab import ui
from astroai_lab.cli.context import merge_opts
from astroai_lab.errors import LabError
from astroai_lab.utils.subprocess import run, run_capture

session_app = typer.Typer(help="Thin wrappers around `canfar` session commands.")

_IMAGE_ALIASES = {
    "webterm": "images.canfar.net/astroai/webterm:latest",
    "vscode": "images.canfar.net/astroai/vscode:latest",
    "notebook": "images.canfar.net/astroai/notebook:latest",
    "marimo": "images.canfar.net/astroai/marimo:latest",
    "ray-manager": "images.canfar.net/astroai/ray-manager:latest",
}


def _require_canfar() -> None:
    if shutil.which("canfar") is None:
        raise LabError(
            "canfar not found on PATH.",
            hint="Install the OpenCADC canfar client, then: canfar auth login",
        )


def _resolve_image(image: str) -> str:
    return _IMAGE_ALIASES.get(image, image)


@session_app.command("create")
def session_create(
    ctx: typer.Context,
    image: Annotated[
        str,
        typer.Option(
            "--image",
            "-i",
            help="Alias (webterm|vscode|notebook|marimo|ray-manager) or full image URL.",
        ),
    ] = "notebook",
    name: Annotated[str | None, typer.Option("--name", "-n")] = None,
    cores: Annotated[int | None, typer.Option("--cores")] = None,
    ram: Annotated[int | None, typer.Option("--ram", help="RAM in GB.")] = None,
    gpu: Annotated[int, typer.Option("--gpu", help="GPU count (0 = CPU node).")] = 0,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """Create a CANFAR session via `canfar create` (convenience wrapper).

    Examples:
        astroai-lab session create --image notebook
        astroai-lab session create --image webterm --gpu 1 --cores 4 --ram 16
    """
    opts = merge_opts(ctx, dry_run=dry_run)
    try:
        _require_canfar()
    except LabError as exc:
        ui.print_error(str(exc))
        raise typer.Exit(1) from exc

    img = _resolve_image(image)
    # Kind heuristic: notebook alias uses notebook type; others contributed.
    kind = "notebook" if image == "notebook" or img.endswith("/notebook:latest") else "contributed"
    cmd = ["canfar", "create", kind, img]
    if name:
        cmd.extend(["--name", name])
    if cores is not None:
        cmd.extend(["--cores", str(cores)])
    if ram is not None:
        cmd.extend(["--ram", str(ram)])
    if gpu > 0:
        cmd.extend(["--gpus", str(gpu)])

    if opts.dry_run:
        ui.print_ok("dry-run: " + " ".join(cmd))
        return
    try:
        out = run_capture(cmd)
    except LabError as exc:
        ui.print_error(str(exc))
        raise typer.Exit(1) from exc
    ui.print_ok(out.strip() or f"Created {img}")


@session_app.command("ps")
def session_ps(
    ctx: typer.Context,
    json_output: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """List sessions (`canfar ps`)."""
    opts = merge_opts(ctx, json_output=json_output)
    try:
        _require_canfar()
        out = run_capture(["canfar", "ps", "--json"] if opts.json else ["canfar", "ps"])
    except LabError as exc:
        ui.print_error(str(exc))
        raise typer.Exit(1) from exc
    typer.echo(out)


@session_app.command("stop")
def session_stop(
    ctx: typer.Context,
    session_id: Annotated[str, typer.Argument(help="Session id.")],
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """Stop a session (`canfar delete`)."""
    opts = merge_opts(ctx, dry_run=dry_run)
    try:
        _require_canfar()
    except LabError as exc:
        ui.print_error(str(exc))
        raise typer.Exit(1) from exc
    cmd = ["canfar", "delete", session_id]
    if opts.dry_run:
        ui.print_ok("dry-run: " + " ".join(cmd))
        return
    try:
        run(cmd)
    except LabError as exc:
        ui.print_error(str(exc))
        raise typer.Exit(1) from exc
    ui.print_ok(f"Stopped {session_id}")


@session_app.command("images")
def session_images() -> None:
    """Show common AstroAI image aliases."""
    for alias, url in _IMAGE_ALIASES.items():
        ui.print_hint(f"  {alias:<12} {url}")
